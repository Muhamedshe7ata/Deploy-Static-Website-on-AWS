hello everyone,

you can access website :
via cloudfront:
https://d2b0icpdqght85.cloudfront.net/
via Bucketname:
http://momobucket152022.s3-website-us-east-1.amazonaws.com/index.html#
